from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    kind TEXT PRIMARY KEY, name TEXT NOT NULL, digest TEXT NOT NULL, body TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS ideas (
    id INTEGER PRIMARY KEY, topic TEXT NOT NULL, context TEXT NOT NULL,
    draft TEXT NOT NULL, source TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending'
        CHECK(status IN ('pending','approved','rejected','changes')),
    feedback TEXT NOT NULL DEFAULT '', revision INTEGER NOT NULL DEFAULT 0,
    scheduled TEXT
);
CREATE TABLE IF NOT EXISTS publications (
    idea_id INTEGER PRIMARY KEY REFERENCES ideas(id), content TEXT NOT NULL,
    source TEXT NOT NULL, archive BLOB NOT NULL
);
"""


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connection() as db:
            db.executescript(SCHEMA)

    @contextmanager
    def connection(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def document(self, kind, name, pdf, body):
        with self.connection() as db:
            db.execute("INSERT OR REPLACE INTO documents VALUES (?, ?, ?, ?)",
                       (kind, name, hashlib.sha256(pdf).hexdigest(), body))

    def documents(self):
        with self.connection() as db:
            return list(db.execute("SELECT * FROM documents ORDER BY kind"))

    def add(self, topic, context, drafts, source):
        with self.connection() as db:
            db.executemany("INSERT INTO ideas(topic, context, draft, source) VALUES (?, ?, ?, ?)",
                           [(topic, context, json.dumps(draft), source) for draft in drafts])

    def ideas(self):
        with self.connection() as db:
            return list(db.execute("SELECT * FROM ideas ORDER BY id DESC"))

    def review(self, idea, status, feedback=""):
        if status not in {"approved", "rejected", "changes"}:
            raise ValueError("Decisión inválida.")
        if status == "changes" and not feedback.strip():
            raise ValueError("Escribe los cambios solicitados.")
        with self.connection() as db:
            self.checked(db.execute("""
                UPDATE ideas SET status=?, feedback=?, revision=revision+1
                WHERE id=? AND revision=? AND status='pending'
            """, (status, feedback, idea["id"], idea["revision"])))

    def revise(self, idea, draft, source):
        with self.connection() as db:
            self.checked(db.execute("""
                UPDATE ideas SET draft=?, source=?, status='pending', revision=revision+1
                WHERE id=? AND revision=? AND status='changes'
            """, (json.dumps(draft), source, idea["id"], idea["revision"])))

    def publish(self, idea, content, source, archive):
        with self.connection() as db:
            self.checked(db.execute("""
                INSERT INTO publications
                SELECT id, ?, ?, ? FROM ideas WHERE id=? AND revision=? AND status='approved'
                ON CONFLICT(idea_id) DO UPDATE SET content=excluded.content,
                    source=excluded.source, archive=excluded.archive
            """, (json.dumps(content), source, archive, idea["id"], idea["revision"])))

    def publication(self, idea_id):
        with self.connection() as db:
            return db.execute("SELECT * FROM publications WHERE idea_id=?", (idea_id,)).fetchone()

    def schedule(self, idea_id, date):
        with self.connection() as db:
            self.checked(db.execute("UPDATE ideas SET scheduled=? WHERE id=? AND status='approved'",
                                    (date.isoformat() if date else None, idea_id)))

    @staticmethod
    def checked(cursor):
        if cursor.rowcount != 1:
            raise ValueError("La idea cambió de estado. Actualiza la página y vuelve a intentar.")
