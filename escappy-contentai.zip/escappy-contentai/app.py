from datetime import date, timedelta
from io import BytesIO
import json
from pathlib import Path
from zipfile import ZipFile

import streamlit as st

from ai import Provider
from content import (COPY_FIELDS, FORMATS, IDEA_FIELDS, SLIDE_FIELDS, extract_pdf,
                     make_archive, validate_content, validate_idea)
from storage import Store

STATUS = {"pending": "Pendiente", "approved": "Aprobada",
          "rejected": "Rechazada", "changes": "Cambios solicitados"}
KINDS = ("Marca", "Buyer persona", "Estrategia comercial")
IDEA_SCHEMA = (
    "Campos title (90 caracteres), hook (150), objective (200), rationale (500), "
    "format (Carrusel o Historia)."
)


def fields(definitions, prefix, values=None):
    values = values or {}
    return {key: st.text_area(label, value=values.get(key, ""), max_chars=limit,
                              height=70, key=f"{prefix}-{key}")
            for key, (label, limit) in definitions.items()}


def idea_editor(prefix, draft=None):
    draft = draft or {}
    values = fields(IDEA_FIELDS, prefix, draft)
    formats = list(FORMATS)
    values["format"] = st.selectbox("Formato", formats, index=formats.index(draft.get("format", formats[0])),
                                    key=f"{prefix}-format")
    return values


def documents_page(store):
    st.header("Documentos de referencia")
    saved = {row["kind"]: row for row in store.documents()}
    for kind in KINDS:
        with st.form(f"pdf-{kind}"):
            file = st.file_uploader(kind, type=["pdf"])
            if kind in saved:
                st.caption(f"Guardado: {saved[kind]['name']}")
            if st.form_submit_button("Extraer y guardar"):
                if file is None:
                    st.error("Selecciona un PDF.")
                    continue
                try:
                    data = file.getvalue()
                    store.document(kind, file.name, data, extract_pdf(data))
                    st.rerun()
                except ValueError as error:
                    st.error(str(error))


def request_ai(provider, store, instruction, **payload):
    if provider is None:
        raise ValueError("Configura el proveedor de IA o selecciona el modo manual.")
    payload["documentos"] = [{"tipo": row["kind"], "texto": row["body"][:6000]}
                             for row in store.documents()]
    return provider.ask(instruction, payload)


def create_ideas(store, manual, provider):
    with st.form("new-ideas"):
        topic = st.text_input("Tema turístico", max_chars=250)
        context = st.text_area("Contexto adicional", max_chars=4000)
        drafts = []
        if manual:
            for index in range(3):
                with st.expander(f"Idea {index + 1}"):
                    drafts.append(idea_editor(f"new-{index}"))
        if st.form_submit_button("Guardar tres ideas" if manual else "Generar tres ideas con IA"):
            try:
                if not topic.strip():
                    raise ValueError("Ingresa un tema turístico.")
                if not manual:
                    drafts = request_ai(provider, store, "Devuelve un arreglo de exactamente tres ideas. "
                                        + IDEA_SCHEMA, tema=topic, contexto=context)
                if not isinstance(drafts, list) or len(drafts) != 3:
                    raise ValueError("Se requieren exactamente tres ideas.")
                store.add(topic.strip(), context.strip(), [validate_idea(draft) for draft in drafts],
                          "Manual" if manual else "IA")
                st.rerun()
            except ValueError as error:
                st.error(str(error))


def review(store, idea):
    with st.form(f"review-{idea['id']}"):
        decision = st.radio("Decisión", ("approved", "rejected", "changes"),
                            format_func=STATUS.get, horizontal=True)
        feedback = st.text_area("Comentarios", max_chars=2000)
        if st.form_submit_button("Guardar decisión"):
            store.review(idea, decision, feedback)
            st.rerun()


def revise(store, idea, draft, manual, provider):
    st.write("Comentarios de revisión")
    st.text(idea["feedback"])
    with st.form(f"revise-{idea['id']}-{idea['revision']}"):
        revised = idea_editor(f"revision-{idea['id']}-{idea['revision']}", draft) if manual else None
        if st.form_submit_button("Enviar a revisión" if manual else "Revisar idea con IA"):
            if not manual:
                revised = request_ai(provider, store, "Devuelve una sola idea revisada como objeto. "
                                     + IDEA_SCHEMA, tema=idea["topic"], contexto=idea["context"],
                                     idea=draft, cambios=idea["feedback"])
            store.revise(idea, validate_idea(revised), "Manual" if manual else "IA")
            st.rerun()


def production(store, idea, draft, manual, provider):
    key = f"publication-{idea['id']}"
    format_name = draft["format"]
    current = store.publication(idea["id"])
    previous = json.loads(current["content"]) if current else {}
    previous_slides = previous.get("slides", [])
    if manual and format_name == "Carrusel":
        count = st.select_slider("Diapositivas", [4, 5, 6], value=len(previous_slides) or 4, key=key)
    else:
        count = 1
    with st.form(f"{key}-form"):
        content = {}
        if manual:
            content = fields(COPY_FIELDS, key, previous)
            content["slides"] = []
            for index in range(count):
                with st.expander(f"Pieza {index + 1}"):
                    old = previous_slides[index] if index < len(previous_slides) else None
                    content["slides"].append(fields(SLIDE_FIELDS, f"{key}-{index}", old))
        if st.form_submit_button("Crear imágenes" if manual else "Generar publicación con IA"):
            if not manual:
                count_hint = "4 a 6 diapositivas" if format_name == "Carrusel" else "una pieza"
                content = request_ai(provider, store,
                                     f"Redacta {count_hint}. Devuelve un objeto con caption "
                                     "(máximo 2000 caracteres), cta (130), y slides, arreglo "
                                     "de objetos con title (75) y body (220).",
                                     tema=idea["topic"], contexto=idea["context"], idea=draft)
            content = validate_content(content, format_name)
            store.publish(idea, content, "Manual" if manual else "IA", make_archive(content, format_name))
            st.rerun()
    if current:
        st.caption(f"Origen del contenido: {current['source']}")
        st.text(previous["caption"])
        st.text(previous["cta"])
        with ZipFile(BytesIO(current["archive"])) as archive:
            columns = st.columns(3)
            for index, name in enumerate(name for name in archive.namelist() if name.endswith(".png")):
                columns[index % 3].image(archive.read(name), caption=name)
        st.download_button("Descargar publicación ZIP", current["archive"],
                           file_name=f"escappy-{idea['id']}.zip", mime="application/zip", key=f"zip-{key}")


def ideas_page(store, manual, provider):
    st.header("Ideas para Instagram")
    create_ideas(store, manual, provider)
    for idea in store.ideas():
        draft = json.loads(idea["draft"])
        with st.expander(f"{STATUS[idea['status']]} · {draft['title']}"):
            st.caption(f"{draft['format']} · {idea['topic']} · {idea['source']}")
            for key in ("hook", "objective", "rationale"):
                st.write(f"**{IDEA_FIELDS[key][0]}**")
                st.text(draft[key])
            try:
                if idea["status"] == "pending":
                    review(store, idea)
                elif idea["status"] == "changes":
                    revise(store, idea, draft, manual, provider)
                elif idea["status"] == "approved":
                    production(store, idea, draft, manual, provider)
            except ValueError as error:
                st.error(str(error))


def calendar_page(store):
    st.header("Calendario editorial")
    today = date.today()
    if "next-week-date" in st.session_state:
        st.session_state["week-date"] = st.session_state.pop("next-week-date")
    chosen = st.date_input("Fecha de la semana", value=today, key="week-date")
    monday = chosen - timedelta(days=chosen.weekday())
    days = [monday + timedelta(days=offset) for offset in range(7)]
    approved = {idea["id"]: idea for idea in store.ideas() if idea["status"] == "approved"}
    if approved:
        chosen_id = st.selectbox("Idea aprobada", list(approved),
                                 format_func=lambda value: json.loads(approved[value]["draft"])["title"])
        scheduled = approved[chosen_id]["scheduled"]
        target = st.date_input("Fecha de publicación", value=date.fromisoformat(scheduled) if scheduled else today,
                               key=f"schedule-{chosen_id}")
        save, clear = st.columns(2)
        if save.button("Programar fecha"):
            store.schedule(chosen_id, target)
            st.session_state["next-week-date"] = target
            st.rerun()
        if clear.button("Quitar fecha"):
            store.schedule(chosen_id, None)
            st.rerun()
    else:
        st.info("Las ideas aprobadas se pueden programar aquí.")
    names = ("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
    for name, day in zip(names, days):
        with st.container(border=True):
            st.subheader(f"{name} {day:%d/%m}")
            entries = [idea for idea in approved.values() if idea["scheduled"] == day.isoformat()]
            for idea in entries:
                draft = json.loads(idea["draft"])
                st.text(f"{draft['title']} · {draft['format']}")
            if not entries:
                st.caption("Sin publicaciones programadas")


def main():
    st.set_page_config(page_title="ESCAPPY CONTENT AI", layout="wide")
    st.title("ESCAPPY CONTENT AI")
    store = Store(Path(__file__).resolve().parent / "data" / "escappy.sqlite3")
    page = st.sidebar.radio("Sección", ("Documentos", "Ideas", "Calendario"))
    mode = st.sidebar.radio("Modo de creación", ("Manual", "IA"))
    provider = None
    if mode == "IA":
        st.sidebar.caption("Se envían extractos de los PDF y el contexto editorial al proveedor elegido.")
        url = st.sidebar.text_input("URL base compatible con OpenAI",
                                    "https://generativelanguage.googleapis.com/v1beta/openai")
        model = st.sidebar.text_input("Modelo", "gemini-2.5-flash")
        key = st.sidebar.text_input("Clave API", type="password")
        try:
            provider = Provider(url, model, key)
        except ValueError as error:
            st.sidebar.error(str(error))
    else:
        st.sidebar.caption("Las ideas y los textos los escribe una persona.")
    if page == "Documentos":
        documents_page(store)
    elif page == "Ideas":
        ideas_page(store, mode == "Manual", provider)
    else:
        calendar_page(store)


if __name__ == "__main__":
    main()
