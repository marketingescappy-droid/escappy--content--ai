from io import BytesIO
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

import pymupdf
from PIL import Image, ImageDraw, ImageFont

FORMATS = {"Carrusel": (1080, 1350), "Historia": (1080, 1920)}
IDEA_FIELDS = {"title": ("Título", 90), "hook": ("Hook", 150),
               "objective": ("Objetivo", 200), "rationale": ("Justificación", 500)}
SLIDE_FIELDS = {"title": ("Título", 75), "body": ("Texto", 220)}
COPY_FIELDS = {"caption": ("Caption", 2000), "cta": ("CTA", 130)}


def clean_fields(value, fields):
    if not isinstance(value, dict):
        raise ValueError("Se esperaba un objeto con campos de texto.")
    result = {}
    for key, (label, limit) in fields.items():
        item = value.get(key)
        if not isinstance(item, str) or not item.strip() or len(item.strip()) > limit:
            raise ValueError(f"{label} debe tener entre 1 y {limit} caracteres.")
        result[key] = item.strip()
    return result


def validate_idea(idea):
    result = clean_fields(idea, IDEA_FIELDS)
    if idea.get("format") not in tuple(FORMATS):
        raise ValueError("El formato debe ser Carrusel o Historia.")
    return {**result, "format": idea["format"]}


def validate_content(content, format_name):
    result = clean_fields(content, COPY_FIELDS)
    slides = content.get("slides")
    allowed = range(4, 7) if format_name == "Carrusel" else range(1, 2)
    if not isinstance(slides, list) or len(slides) not in allowed:
        raise ValueError("Usa 4 a 6 diapositivas para un carrusel o una para una historia.")
    return {**result, "slides": [clean_fields(slide, SLIDE_FIELDS) for slide in slides]}


def extract_pdf(data):
    if len(data) > 15 * 1024 * 1024:
        raise ValueError("Cada PDF admite hasta 15 MB.")
    try:
        with pymupdf.open(stream=data, filetype="pdf") as pdf:
            if pdf.needs_pass or len(pdf) > 250:
                raise ValueError("Usa un PDF sin contraseña de hasta 250 páginas.")
            body = "\n".join(page.get_text() for page in pdf).strip()
    except (pymupdf.FileDataError, RuntimeError) as error:
        raise ValueError("No se pudo leer el PDF.") from error
    if not body:
        raise ValueError("El PDF no contiene texto extraíble. Aplica OCR antes de cargarlo.")
    return body


def font(size, bold=False):
    windows = Path("C:/Windows/Fonts") / ("arialbd.ttf" if bold else "arial.ttf")
    fallback = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    for name in (str(windows), fallback):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return ImageFont.load_default(size=size)


def wrap(draw, text, face, width):
    lines = []
    for paragraph in text.splitlines():
        line = ""
        for word in paragraph.split():
            candidate = f"{line} {word}".strip()
            if line and draw.textlength(candidate, font=face) > width:
                lines.append(line)
                line = ""
            if draw.textlength(word, font=face) > width:
                chunk = ""
                for char in word:
                    if draw.textlength(chunk + char, font=face) > width:
                        lines.append(chunk)
                        chunk = ""
                    chunk += char
                line = chunk
            else:
                line = f"{line} {word}".strip()
        lines.append(line)
    return "\n".join(lines)


def block(draw, text, y, max_height, start, bold=False):
    for size in range(start, 25, -2):
        face = font(size, bold)
        lines = wrap(draw, text, face, 864)
        box = draw.multiline_textbbox((0, 0), lines, font=face, spacing=12)
        if box[3] - box[1] <= max_height:
            draw.multiline_text((108, y - box[1]), lines, font=face, fill="#14251A", spacing=12)
            return
    raise ValueError("Acorta el texto para que quepa en la imagen.")


def make_archive(content, format_name):
    width, height = FORMATS[format_name]
    data = BytesIO()
    with ZipFile(data, "w", ZIP_DEFLATED) as archive:
        for index, slide in enumerate(content["slides"], 1):
            image = Image.new("RGB", (width, height), "#F7F9F3")
            draw = ImageDraw.Draw(image)
            draw.rectangle((108, 145, 254, 159), fill="#49B232")
            draw.text((108, 202), "ESCAPPY TRAVEL", font=font(29, True), fill="#14251A")
            block(draw, slide["title"], height * .24, height * .23, 84, True)
            block(draw, slide["body"], height * .51, height * .27, 51)
            draw.line((108, height - 190, 972, height - 190), fill="#49B232", width=4)
            footer = f"{index} / {len(content['slides'])}" if format_name == "Carrusel" else "ESCAPPY TRAVEL"
            draw.text((108, height - 156), footer, font=font(30), fill="#14251A")
            png = BytesIO()
            image.save(png, format="PNG")
            archive.writestr(f"{index:02d}.png", png.getvalue())
        archive.writestr("caption.txt", content["caption"] + "\n\nCTA\n" + content["cta"] + "\n")
    return data.getvalue()
