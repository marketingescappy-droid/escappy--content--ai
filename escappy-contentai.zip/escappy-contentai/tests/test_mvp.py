from datetime import date
from io import BytesIO
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
from urllib.error import HTTPError
from zipfile import ZipFile

from PIL import Image
import pymupdf

from ai import Provider
from content import FORMATS, extract_pdf, make_archive, validate_content, validate_idea
from storage import Store

IDEA = {"title": "Viaje a Salento", "hook": "Prepara tu viaje", "objective": "Orientar",
        "format": "Carrusel", "rationale": "Responde dudas de planificación."}
SLIDE = {"title": "Planea tu visita", "body": "Selecciona tus fechas y deja tiempo para recorrer."}


class StoreTests(unittest.TestCase):
    def setUp(self):
        folder = TemporaryDirectory()
        self.addCleanup(folder.cleanup)
        self.path = Path(folder.name) / "test.sqlite3"
        self.store = Store(self.path)
        self.store.add("Salento", "Viaje en familia", [validate_idea(IDEA)], "Manual")

    def test_approval_revision_and_persistence(self):
        idea, = self.store.ideas()
        with self.assertRaises(ValueError):
            self.store.publish(idea, {}, "Manual", b"zip")
        with self.assertRaises(ValueError):
            self.store.review(idea, "changes")
        self.store.review(idea, "changes", "Enfocar en familias")
        with self.assertRaises(ValueError):
            self.store.review(idea, "approved")
        revised_title = "Salento en familia"
        pending, = self.store.ideas()
        self.store.revise(pending, {**IDEA, "title": revised_title}, "Manual")
        revised, = self.store.ideas()
        self.store.review(revised, "approved")
        approved, = self.store.ideas()
        self.store.publish(approved, {"caption": "Viaja en familia"}, "Manual", b"zip")
        self.store.schedule(approved["id"], date(2026, 11, 23))
        reopened = Store(self.path)
        saved, = reopened.ideas()
        self.assertEqual(json.loads(saved["draft"])["title"], revised_title)
        self.assertEqual(saved["scheduled"], "2026-11-23")
        self.assertEqual(reopened.publication(saved["id"])["archive"], b"zip")
        reopened.schedule(saved["id"], None)
        self.assertIsNone(reopened.ideas()[0]["scheduled"])

    def test_rejection_blocks_production_and_scheduling(self):
        self.store.review(self.store.ideas()[0], "rejected")
        idea, = self.store.ideas()
        with self.assertRaises(ValueError):
            self.store.publish(idea, {}, "Manual", b"zip")
        with self.assertRaises(ValueError):
            self.store.schedule(idea["id"], date.today())

    def test_pdf_text_is_stored(self):
        with pymupdf.open() as document:
            document.new_page().insert_text((72, 72), "Escappy Travel")
            pdf = document.tobytes()
        self.store.document("Marca", "marca.pdf", pdf, extract_pdf(pdf))
        self.assertEqual(Store(self.path).documents()[0]["body"], "Escappy Travel")
        with self.assertRaises(ValueError):
            extract_pdf(b"invalid")


class ExportTests(unittest.TestCase):
    def test_zip_images_and_caption(self):
        for format_name, count in [("Carrusel", 4), ("Carrusel", 6), ("Historia", 1)]:
            with self.subTest(format_name=format_name, count=count):
                content = validate_content({"caption": "Viaja", "cta": "Escríbenos",
                                            "slides": [SLIDE] * count}, format_name)
                with ZipFile(BytesIO(make_archive(content, format_name))) as archive:
                    self.assertEqual(len(archive.namelist()), count + 1)
                    self.assertIn("Escríbenos", archive.read("caption.txt").decode())
                    for index in range(1, count + 1):
                        with Image.open(BytesIO(archive.read(f"{index:02d}.png"))) as image:
                            self.assertEqual(image.size, FORMATS[format_name])
                            self.assertEqual(image.format, "PNG")
                            self.assertEqual(image.getpixel((110, 150)), (73, 178, 50))

    def test_invalid_slide_count(self):
        with self.assertRaises(ValueError):
            validate_content({"caption": "Viaja", "cta": "Escríbenos", "slides": [SLIDE]}, "Carrusel")


class ProviderTests(unittest.TestCase):
    @patch("ai.build_opener")
    def test_uses_remote_json(self, opener):
        reply = {"choices": [{"message": {"content": json.dumps([IDEA] * 3)}}]}
        instance = opener.return_value
        instance.open.return_value.__enter__.return_value.read.return_value = json.dumps(reply).encode()
        client = Provider("https://example.test/v1", "test-model", "test-key")
        self.assertEqual(client.ask("Genera tres ideas", {}), [IDEA] * 3)
        request = instance.open.call_args.args[0]
        self.assertEqual(request.full_url, "https://example.test/v1/chat/completions")
        self.assertEqual(request.get_header("Authorization"), "Bearer test-key")

    @patch("ai.build_opener")
    def test_quota_error_does_not_return_sample_content(self, opener):
        opener.return_value.open.side_effect = HTTPError("https://example.test", 429, "", {}, None)
        with self.assertRaisesRegex(ValueError, "429"):
            Provider("https://example.test", "model", "").ask("Genera ideas", {})
