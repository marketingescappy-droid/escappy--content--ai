# ESCAPPY CONTENT AI

Aplicación local de Escappy Travel para planificar y crear publicaciones de Instagram con revisión humana.

## Instalar en Windows

1. Instala Python 3.11 o posterior y habilita su lanzador de Windows o agrégalo al PATH.
2. Descarga y descomprime el repositorio o clónalo con Git.
3. Abre `iniciar.bat`. El archivo crea un entorno virtual, instala las dependencias y ejecuta Streamlit.
4. Si el navegador no abre automáticamente, visita http://127.0.0.1:8501. Presiona Ctrl+C en la terminal para detener la aplicación.

También puedes ejecutar estos comandos desde PowerShell en la carpeta del proyecto:

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1
```

En Linux o macOS, sustituye `py -3` por `python3` y usa `.venv/bin/python`.

## Flujo editorial

1. En **Documentos**, carga un PDF por categoría: marca, buyer persona y estrategia comercial. Cada carga reemplaza el documento de su categoría.
2. Elige **Manual** o **IA** en la barra lateral. En **Ideas**, escribe un tema turístico y agrega el contexto necesario. En modo manual, redacta las tres ideas en sus formularios. En modo IA, el proveedor redacta las tres.
3. Revisa cada idea. Puedes aprobar, rechazar o solicitar cambios. Una propuesta corregida vuelve a quedar pendiente de aprobación.
4. Abre la idea aprobada para redactar manualmente o generar con IA. La aplicación crea un carrusel de 4 a 6 PNG de 1080 × 1350, o una historia en PNG de 1080 × 1920. Puedes previsualizar las piezas y descargar un ZIP con las imágenes, el caption y el CTA.
5. Usa **Calendario** para asignar fechas a ideas aprobadas y consultar su distribución semanal.

SQLite guarda el texto de los PDF, las ideas, sus estados, las fechas y las publicaciones con sus archivos ZIP. Para respaldar el trabajo, cierra la aplicación y copia `data/escappy.sqlite3`.

## Configurar IA

Introduce la URL base compatible con Chat Completions de OpenAI, el identificador del modelo y su clave. La aplicación agrega `/chat/completions`. La clave puede introducirse en el campo de contraseña o en la variable de entorno `ESCAPPY_AI_KEY`. La aplicación no guarda la clave en SQLite.

La configuración inicial apunta a la API compatible con OpenAI de Gemini. Crea una clave en [Google AI Studio](https://aistudio.google.com/apikey) y comprueba la [disponibilidad de cuota gratuita](https://ai.google.dev/gemini-api/docs/pricing) para tu cuenta y el modelo elegido. Puedes cambiar de modelo o proveedor desde la barra lateral. El modo manual funciona sin claves ni conexión tras instalar las dependencias.

Cada solicitud de IA envía al proveedor seleccionado hasta 6000 caracteres de cada PDF, además del tema, el contexto y, cuando corresponda, el borrador y los comentarios. Usa documentos que tengas autorización para compartir con ese proveedor.

## Alcance del MVP

Se admiten PDF con texto seleccionable de hasta 15 MB y 250 páginas por archivo. Los PDF escaneados requieren aplicar OCR antes de cargarlos. La aplicación utiliza el contexto aportado y no investiga en internet. Revisa datos de viajes antes de usar el contenido. El calendario organiza fechas editoriales. La publicación en Instagram, Canva y el scraping quedan fuera del MVP.

## Pruebas

Desde el entorno virtual, ejecuta:

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```
